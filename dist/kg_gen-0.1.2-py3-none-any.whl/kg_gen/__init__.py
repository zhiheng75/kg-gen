from .kg_gen import KGGen 
from .models import Graph
from .t2kg import T2KG
from .models import Graph